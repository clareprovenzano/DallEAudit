# Data Table

Notion allows you to upload an image from you computer (Image column), but I can make a Google Drive as well to put the images in so we all have access to them.

DallE 3 ethnic/racial categories:

- Middle Eastern
- African (Black)
- Asian (East Asian, light skin, dark (black) hair, dark eyes. Chinese/Korean/Japanese looking)
- Southeast Asian
- Indigenous
- North American
- South American
- Latina (light skin, dark hair, dark eyes)
- Caucasian
- European
- Indigenous (light brown skin, dark hair, dark eyes)
- South Asian
- Southeast European
- North European

Terms (my own terms I used when categorizing DallE 2 images):

Asian = East Asian

South Asian = Indian, Pakistani

Ambiguous Ethnicity = I’m not sure

No Face = no face in photo 

notes:

- GPT adds race, gender, background (office, posters, etc), adjectives (confident), actions (looking at an x-ray)
- Some have wedding rings, watches, etc
- Anatomy is a lot better and more realistic, even like flyway or messy hair looks very realistic
- DIANA QUESTION: are you considering if serius/smiling or any emotion being explicitly/intentionally shown?

[Dataset](Dataset%20342ca020f454408d9ec733bc478b7aaf.csv)

[https://chatgpt.com/share/6788072a-5e60-8013-b97b-6abeb0b1eaae](https://chatgpt.com/share/6788072a-5e60-8013-b97b-6abeb0b1eaae)